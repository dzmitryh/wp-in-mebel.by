jQuery(document).ready(function($) {
 // clear cf7 error msg on mouseover
 $(".wpcf7-form-control-wrap").mouseover(function(){
  $obj = $("span.wpcf7-not-valid-tip",this);
      $obj.fadeOut();
 });
});